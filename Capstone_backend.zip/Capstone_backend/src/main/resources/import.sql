-- Table structure for order_main
INSERT INTO temp.order_main VALUES ( 5,'Rajahmundry','harish@gmail.com','harish',98765,'2022-07-06 19:25:13.821428',40.00,2,'2022-07-06 20:21:06.556261');
INSERT INTO temp.order_main VALUES ( 6,'Rajahmundry','harish@gmail.com','harish',98765,'2022-07-06 19:25:13.821428',40.00,2,'2022-07-06 20:21:06.556261');
INSERT INTO temp.order_main VALUES ( 7,'Rajahmundry','harish@gmail.com','harish',98765,'2022-07-06 19:25:13.821428',40.00,2,'2022-07-06 20:21:06.556261');
INSERT INTO temp.order_main VALUES ( 10,'Rajahmundry','harish@gmail.com','harish',98765,'2022-07-06 19:25:13.821428',40.00,2,'2022-07-06 20:21:06.556261');
INSERT INTO temp.order_main VALUES ( 16,'hyderabad','vamsi@gmail.com','vamsi',12345,'2022-07-06 19:25:13.821428',40.00,2,'2022-07-06 20:21:06.556261');
INSERT INTO temp.order_main VALUES ( 18,'hyderabad','vamsi@gmail.com','vamsi',12345,'2022-07-06 19:25:13.821428',40.00,2,'2022-07-06 20:21:06.556261');
INSERT INTO temp.order_main VALUES ( 24,'Guntur','yash@gmail.com','Yashwanth',2341845,'2022-07-06 19:25:13.821428',40.00,2,'2022-07-06 20:21:06.556261');

-- Table structure for product_category
INSERT INTO temp.product_category VALUES ("2147483641","Furniture","0","2018-03-09 23:03:26.000000","2018-03-10 00:15:27.000000");
INSERT INTO temp.product_category VALUES ("2147483642","Kitchen","2","2018-03-10 00:15:02.000000","2018-03-10 00:15:21.000000");
INSERT INTO temp.product_category VALUES ("2147483644","Home Decor","3","2018-03-10 01:01:09.000000","2018-03-10 01:01:09.000000");
INSERT INTO temp.product_category VALUES ("2147483645","Electronic","1","2018-03-09 23:03:26.000000","2018-03-10 00:15:27.000000");

-- Table structure for product_category
select * from product_in_order;
INSERT INTO temp.product_in_order VALUES (22,3,1,"Aluminum Plastic Wall Clock","https://m.media-amazon.com/images/I/71AoA2F0RhL._AC_UL480_FMwebp_QL65_.jpg","D0001",'Clock',22.0,100,null,24);
INSERT INTO temp.product_in_order VALUES (26,3,2,"Wooden Wall Hangings for Home Decoration","https://m.media-amazon.com/images/I/81o-KlpBYAS._AC_UL480_FMwebp_QL65_.jpg","D0002",'Wall Decor',39.0,20,null,27);
INSERT INTO temp.product_in_order VALUES (28,2,1,"Mixer with four Jars","https://m.media-amazon.com/images/I/71Wq0mQNTLL._SX679_.jpg","C0002",'Mixer Grinder',56.00,76,null,29);
INSERT INTO temp.product_in_order VALUES (30,0,1,"The Sleep Company Smart Grid High-Back Chair For Office & Home","https://m.media-amazon.com/images/I/815M0u6oXRL._AC_UL480_QL65_.jpg","B0004",'Chairs',119.00,42,null,null);
INSERT INTO temp.product_in_order VALUES (33,0,1,"The Sleep Company Smart Grid High-Back Chair For Office & Home","https://m.media-amazon.com/images/I/815M0u6oXRL._AC_UL480_QL65_.jpg","B0004",'Chairs',119.0,42,null,56);
INSERT INTO temp.product_in_order VALUES (34,0,1,"4 Seater Dining Table Chair Set","https://images-eu.ssl-images-amazon.com/images/G/31/IMG21/Furniture/2021/Popular-Categories-_Desktop_22.jpg","B0002",'Dining Table',199.0,29,2,null);
INSERT INTO temp.product_in_order VALUES (35,1,1,"Croma 80 cm (32 Inches) HD Ready Certified Android Smart LED TV ","https://m.media-amazon.com/images/I/61XouL+PH-L._SX522_.jpg","F0001",'LED TV',229.0,24,2,null);
INSERT INTO temp.product_in_order VALUES (36,0,1,"4 Seater Dining Table Chair Set","https://images-eu.ssl-images-amazon.com/images/G/31/IMG21/Furniture/2021/Popular-Categories-_Desktop_22.jpg","B0002",'Dining Table',199.0,29,2,null);
INSERT INTO temp.product_in_order VALUES (55,2,2,"Mixer with four Jars","https://m.media-amazon.com/images/I/71Wq0mQNTLL._SX679_.jpg","C0002",'Mixer Grinder',56.0,75,null,56);
INSERT INTO temp.product_in_order VALUES (93,2,3,"Mixer with four Jars","https://m.media-amazon.com/images/I/71Wq0mQNTLL._SX679_.jpg","C0002",'Mixer Grinder',56.0,75,null,106);
INSERT INTO temp.product_in_order VALUES (97,1,1,"LG 270 L 3 Star Inverter Direct-Cool Single Door Refrigerator�","https://images-eu.ssl-images-amazon.com/images/I/312HPeK-bGL._SX342_SY445_QL70_FMwebp_.jpg","E0008",'Refrigerator',399.00,29,null,106);

-- Records of product_info

INSERT INTO temp.product_info VALUES("B0002",0,"2018-03-10 10:35:43.000000","4 Seater Dining Table Chair Set","https://images-eu.ssl-images-amazon.com/images/G/31/IMG21/Furniture/2021/Popular-Categories-_Desktop_22.jpg","Dining Table",199.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("B0003",0,"2018-03-10 10:37:39.000000","Wakefit King Size Leo Engineered Wood Platform Bed","https://images-eu.ssl-images-amazon.com/images/G/31/IMG21/Furniture/2021/Popular-Categories-_Desktop_12.jpg","Bed",176.00,1,0,"2022-07-07 15:26:35.983000");
INSERT INTO temp.product_info VALUES("B0004",0,"2018-03-10 10:39:29.000000","The Sleep Company Smart Grid High-Back Chair For Office & Home","https://m.media-amazon.com/images/I/815M0u6oXRL._AC_UL480_QL65_.jpg","Chairs",119.00,0,41,"2022-07-12 10:58:29.771000");
INSERT INTO temp.product_info VALUES("B0005",0,"2018-03-10 10:40:35.000000","Solimo Tracy Engineered Wood Wall Mounted Dressing Table","https://m.media-amazon.com/images/I/71hb0KYhm8L._AC_UL480_QL65_.jpg","Dressing Table",42.00,0,34,"2022-07-07 15:29:11.380000");
INSERT INTO temp.product_info VALUES("C0001",2,"2018-03-10 12:09:41.000000","3 Burner Gas Stove","https://images-eu.ssl-images-amazon.com/images/I/51TYBmz4JXL._AC._SR360,460.jpg","Gas Stove",47.00,0,24,"2022-07-07 15:29:49.187000");
INSERT INTO temp.product_info VALUES("C0002",2,"2018-03-10 12:11:51.000000","Mixer with four Jars","https://m.media-amazon.com/images/I/71Wq0mQNTLL._SX679_.jpg","Mixer Grinder",56.00,0,71,"2022-07-13 16:36:06.291000");
INSERT INTO temp.product_info VALUES("C0003",2,"2018-03-10 12:12:46.000000","Hot and Cold Water Bottle","https://m.media-amazon.com/images/I/61c-GtJ+0eL._SX679_.jpg","Milton Bottle",8.00,0,19,"2022-07-07 15:31:00.787000");
INSERT INTO temp.product_info VALUES("D0001",3,"2018-03-10 06:51:03.000000","Aluminum Plastic Wall Clock","https://m.media-amazon.com/images/I/71AoA2F0RhL._AC_UL480_FMwebp_QL65_.jpg","Clock",22.00,0,99,"2022-07-09 19:43:23.133000");
INSERT INTO temp.product_info VALUES("D0002",3,"2018-03-10 12:08:17.000000","Wooden Wall Hangings for Home Decoration","https://m.media-amazon.com/images/I/81o-KlpBYAS._AC_UL480_FMwebp_QL65_.jpg","Wall Decor",39.00,0,20,"2022-07-12 10:59:48.824000");
INSERT INTO temp.product_info VALUES("D0003",3,"2022-07-07 16:49:13.066000","WallDaddy Square Preciser 3D Acrylic Home Decorative Art Mirror Wall Stickers Silver","https://images-eu.ssl-images-amazon.com/images/I/61Kys8EZIIL._AC._SR360,460.jpg","Mirror",12.00,0,18,"2022-07-07 16:49:13.066000");
INSERT INTO temp.product_info VALUES("E0005",1,"2022-07-12 13:06:08.863000","1100 W Dry Iron with Black Weilburger Soleplate�","https://m.media-amazon.com/images/I/71q7meZ82qL._SX679_.jpg","Iron Box",79.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("E0007",1,"2022-07-12 13:06:08.863000","Whirlpool 1.5 Ton 3 Star, Inverter Split AC�","https://images-eu.ssl-images-amazon.com/images/I/21bg5ZO5ToL._SY445_SX342_QL70_FMwebp_.jpg","Air Conditioners",499.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("E0010",1,"2022-07-12 13:06:08.890000","Bosch 6 kg 5 Star Fully Automatic Front Loading Washing Machine with In - built Heater�","https://m.media-amazon.com/images/I/61v2jxdd5zL._SX679_.jpg","Washing Machine",369.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("E0011",1,"2022-07-12 13:06:08.893000","IFB 30 L Convection Microwave Oven�","https://m.media-amazon.com/images/I/81D8pNFmWzL._SX679_.jpg","Microwave Oven",179.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("F0001",1,"2018-03-10 12:15:05.000000","Croma 80 cm (32 Inches) HD Ready Certified Android Smart LED TV ","https://m.media-amazon.com/images/I/61XouL+PH-L._SX522_.jpg","LED TV",299.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("F0002",1,"2018-03-10 12:16:44.000000","Zebronics Wireless Bluetooth Multimedia Speaker With Supporting SD Card ","https://m.media-amazon.com/images/I/71GJmUcJkgS._SX679_.jpg","Home Theater",29.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("F0003",1,"2022-07-07 16:49:13.097000","5 liter Electric Pressure Cooker with SS Pot","https://images-eu.ssl-images-amazon.com/images/G/31/IMG21/Furniture/2021/Popular-Categories-_Desktop_22.jpg","Rice Cooker",29.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("F0006",0,"2022-07-09 18:12:39.694000","HomeTown Mezzola Engineered Wood 3 Tier Bookshelf in Wenge & White Color","https://m.media-amazon.com/images/I/61wUxiJJ5bL._SL1100_.jpg","Book Case",199.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("F0007",0,"2022-07-09 18:12:39.727000","Wooden Chest of Drawer for Bed Room","https://m.media-amazon.com/images/I/91acnroY5yL._AC_UL480_FMwebp_QL65_.jpg","Drawer",179.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("F0008",0,"2022-07-09 18:12:39.731000","1 Seater Fabric Manual Recliner with Cup Holder�","https://m.media-amazon.com/images/I/91S9c-cZZEL._SX679_.jpg","Recliner",149.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("F0009",0,"2022-07-09 18:12:39.733000","Inditradition Rope Hammock with Wooden Spreader Bars","https://m.media-amazon.com/images/I/61XWkuY+D5L.jpg","Hammock",99.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("F0010",0,"2022-07-09 18:12:39.735000","Mini Bar on Wheels","https://m.media-amazon.com/images/I/91dWjslBuBL._SX679_.jpg","Bar Cabinet",129.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("H0004",3,"2022-07-10 21:14:11.200000","Wolpin Wall Stickers DIY Wallpaper (45 x 500 cm) Black Damask Luxury Self Adhesive Decals Li","https://images-eu.ssl-images-amazon.com/images/I/514e6uvF-HL._AC_SX368_.jpg","Wall Stickers",8.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("H0006",3,"2022-07-10 21:14:11.200000","Antique Horse Idol for Living Room Wall Shelf Office Shop Festive Gifting","https://m.media-amazon.com/images/I/51eKnuj-+JL.jpg","Horse Idol",15.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("H0007",3,"2022-07-10 21:14:11.200000","YTC Artificial Plants for Home Decor -Best Different Types of Plants","https://m.media-amazon.com/images/I/81jMMucgcRS._SX679_.jpg","Plants for Home",5.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("H0008",3,"2022-07-10 21:14:11.200000","Kriwin Acrylic Rangoli Decorative (10-to 11 inches Multicolor) Reusable","https://m.media-amazon.com/images/I/71WcJ5CwYHL._SX679_.jpg","Rangoli",5.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("H0009",3,"2022-07-10 21:14:11.200000","Rare Handcrafted 3D Ceramic Decorative Plate with Stand, Floral Plates for Living Room","https://m.media-amazon.com/images/I/71QkVVbqHQL._SX679_.jpg","Decorative Plate",12.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("K0004",2,"2022-07-10 21:14:11.20000","Cello Prima Induction Base Non-Stick Aluminium Pan Cookware Set, 3-Pieces, Cherry Red","https://m.media-amazon.com/images/I/7169jlr-0mL._SX679_.jpg","Aluminium Pane",19.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("K0005",2,"2022-07-10 21:14:11.20000","Cello Checkers Plastic PET Canister Set, 18 Pieces, Clear","https://m.media-amazon.com/images/I/71ZmmLW97YL._SX679_.jpg","Canister Set",8.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("k0006",2,"2022-07-10 21:14:11.20000","FnP CL Ceramic Tea and Coffee Cup - 6 Pieces, Glossy Golden","https://images-eu.ssl-images-amazon.com/images/I/812VOfjXlaL._AC._SR360,460.jpg","Coffee Cup",4.00,0,28,"2022-07-12 10:58:29.747000");
INSERT INTO temp.product_info VALUES("K0007",2,"2022-07-10 21:14:11.20000","6 Pieces Professional Kitchen Knife Set, Meat Knife, Chef�s Knife with Non-Slip Handle for Home Kitchen","https://m.media-amazon.com/images/I/81ZDgX1KbNL._SX679_.jpg","Knife Set",11.00,0,28,"2022-07-12 10:58:29.747000");


-- Records of users
INSERT INTO temp.users values(1,1,"2-50, mutyalapadu,lingasamudram mandal","manmadhak49@gmail.com","Manmadha","$2a$10$kInX.47r5DOTCO60gesEA.SOXdBGLqb7ef1hSiJ3x1v2gqAkGhGN.","+916302690363","ROLE_ADMIN");
INSERT INTO temp.users values(2,1,"hyderabad","vamsi@gmail.com","vamsi","$2a$10$L3cuItNCFR/1lSq9Q6DYdun6h9axShK7g5mpYamrx7kD/LQPYIvl6","12345","ROLE_USER");
INSERT INTO temp.users values(21,1,"Guntur","yash@gmail.com","Yashwanth","$2a$10$lTuUGdosDTfGSzdrvRnrN.mPkxD2VRFVbGCwXspwwU5oBFD5gpsSi","2341845","ROLE_ADMIN");
INSERT INTO temp.users values(99,1,"Bangalure","sandesh@gmail.com","Sandesh R","$2a$10$3cgUf6v3V1o68dpFt.f0BOYHmw0NxKEUKnYG3FGG3lORFrtGii2am","12345","ROLE_ADMIN");
INSERT INTO temp.users values(108,1,"Guntur","dev@gmail.com","KIREETI DEV","$2a$10$Cuzr48SCIMbblJZbhUkviu8pcHvSCrKCfWGcdG.2NoHpGTovVsHtG","9867453621","ROLE_ADMIN");
INSERT INTO temp.users values(109,1,"Hyderabad","vijay@gmail.com","Vijay","$2a$10$q1C./GVsU2aEF0vdkTIfSe6H.DP8afjNh9o.LgpYSg62g1TSMI89C","7645234321","ROLE_ADMIN");
INSERT INTO temp.users values(110,1,"mutyalapadu,lingasamudram mandal","maneel@gmail.com","Maneel Kumar","$2a$10$j8nO/fD7FYHL9W/RtqgCk.Sv/jx.sTJHAJRBtEmj.DGogSFfsR752","9398388261","ROLE_USER");

-- Records of cart


INSERT INTO temp.cart VALUES(1);
INSERT INTO temp.cart VALUES(2);
INSERT INTO temp.cart VALUES(21);
INSERT INTO temp.cart VALUES(99);
INSERT INTO temp.cart VALUES(108);
INSERT INTO temp.cart VALUES(109);
INSERT INTO temp.cart VALUES(110);